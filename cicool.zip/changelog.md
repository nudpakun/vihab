Version 3.0.3 (Oct 26, 2019)

- update to modular system (HMVC)
- update logo on setting 
- bug fix
- new menu search

Version 3.0.0 (Jul 26, 2019)

- update to modular system (HMVC)
- update logo on setting 
- bug fix
- new menu search


Version 2.8.0 (Sep 20, 2018)

- extension disquss on blog
- bug fixing
- new clean blog
- extension db backup & restore 


Version 2.6.8 (May 03, 2018)

- extension API update
- bug fixing
- new extension disable builder


Version 2.6.6 (April 25, 2018)

- extension install and update
- bug fixing
- new theme material design


Version 2.6.3 (April 02, 2018)

- extension manager 
- Inactive menu 
- update codeigniter 3.1.8 
- password reminder 
- permission folder wizzard 
- add whoops error handler 
- bug fixing


Version 2.5.8 (Feb 07, 2018)

- support PHP 7.1.x
- dashboard visibility 
- fix join same table 
- language parameter API ex : hostname/api/blog/add?lang=english


Version 2.5.5 (Dec 08, 2017)

- codeigniter debugbar 
- automatic switching language by ip address 
- language update
- fix crud always checked show detail page checkbox 
- change menu and access style
- advance configuration


Version 2.5.0 (Sept 26, 2017)

- choose icon on menu module
- google social login
- setup id and secret on module setting
- adding a new field when there is field update in the database
- custom field label on crud builder


Version 2.3.0 (Agust 09, 2017)

- fix minor bugs
- auto join table input select type
- multi language


Version 2.1.0 (March 17, 2017)

- fix minor bugs
- add count on api response


Version 2.0.0 (February11, 2017)

- setting for default landing from page
- fix bug loader on nginx
- multiple file upload crud builder
- add validation max item for multiple file
- responsive table
- export data to PDF
- example chart
- add carousel


Version 1.9.5 (January 07, 2017)

- Add a new input type on crud builder : timestamp, current user username, current user id
- Add a new input type on form builder : timestamp
- Add a new input type on rest builder : timestamp
- Collapse menu on page detail on backend
- Add information on API Keys
- Add meta data for SEO
- Change the layout of the user profile
- Minor bugs


Version 1.8.1 (December 19, 2016)

- Release of this script on Codecanyon.
