define({
  "name": "Cicool Documentation",
  "version": "0.1.0",
  "description": "API DOC Cicool",
  "title": "Cicool application",
  "url": "",
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2016-10-29T12:51:55.712Z",
    "url": "http://apidocjs.com",
    "version": "0.16.1"
  }
});
